<?php

return array (
  'previous' => '« Précédent',
  'next' => 'Suivant »',
);
