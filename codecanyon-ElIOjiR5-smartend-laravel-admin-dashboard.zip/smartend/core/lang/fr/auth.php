<?php

return array (
  'failed' => 'Ces informations d\'identification ne correspondent pas à nos enregistrements.',
  'throttle' => 'Trop de tentatives de connexion. Veuillez réessayer dans :seconds secondes.',
);
