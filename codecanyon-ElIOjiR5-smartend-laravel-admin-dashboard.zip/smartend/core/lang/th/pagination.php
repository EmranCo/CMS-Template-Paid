<?php

return array (
  'previous' => '&laquo; ย้อนกลับ',
  'next' => 'ถัดไป &raquo;',
);
