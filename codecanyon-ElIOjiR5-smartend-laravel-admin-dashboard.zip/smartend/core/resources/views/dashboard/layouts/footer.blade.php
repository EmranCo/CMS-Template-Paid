<div class="app-footer">
    <div class="p-a text-xs">
        <div class="pull-right text-muted">
            &copy;<?php echo date("Y") ?> Copyright
            <strong>Smartend {{ Helper::system_version() }}</strong>
            <a ui-scroll-to="content"><i class="fa fa-long-arrow-up p-x-sm"></i></a>
        </div>
        <div class="nav">
            &nbsp;
        </div>
    </div>
</div>
